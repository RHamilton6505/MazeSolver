#include <iostream>
#include <cmath>
#include <string>
#include <iomanip>

using namespace std;

class amortizationTable{

  int totalMonths;
  double startingPrinciple, interestRate, extraPay, monthlyPayment;


public:

  amortizationTable(int months, double principle, double rate, double extra);
  amortizationTable(void);
  double calculateMonthlyPayment();
  double getMonthlyPayment();
  double getInterestRate();
  double getStartingPrinciple();
  double getExtraPay();
  void setMonth();
  void setPrinciple();
  void setInterestRate();
  void setExtraPay();

};

class currentMonthData{
  int currentMonth;
  double startingPrinciple, interestRate, extraPay, monthlyPayment, totalPrinciple;
  double principleRemaining, principlePaid, interestPaid;
  double totalPaid, totalPrinciplePaid, totalInterestPaid;

public:
  currentMonthData(double monthlyPayment, double totalPrinciple, double interestRate, double extraPay);
  currentMonthData(int currentMonth, double monthlyPayment, double totalPrinciple, double startingPrinciple, double interestRate, double totalPrinciplePaid, double totalInterestPaid, double extraPay);
  void printCurrentMonth();
  void calculateMonth();
  void reimburseRemainder();
};

/***********************************************************/

amortizationTable::amortizationTable(int inputTotalMonths, double inputStartingPrinciple, double inputInterestRate, double inputExtraPay){
  totalMonths = inputTotalMonths;
  startingPrinciple = inputStartingPrinciple;

  // APR is adjusted to monthly by dividng by 12
  interestRate = inputInterestRate/12;
  extraPay = inputExtraPay;



  monthlyPayment = calculateMonthlyPayment();
}


  // M = (monthlyIR*principle*(1+montlyIR)^totalMonths)/(-1+(1+monthlyIR)^totalMonths)
double amortizationTable::calculateMonthlyPayment(){
  double monthlyPaymentCalc, numerator, denominator;

  numerator = interestRate*startingPrinciple*pow(1+interestRate,totalMonths);
  denominator = -1+pow(1+interestRate,totalMonths);
  monthlyPaymentCalc = numerator/denominator;

  return monthlyPaymentCalc;
}

double amortizationTable::getMonthlyPayment(){
  return monthlyPayment;
}

double amortizationTable::getInterestRate(){
  return interestRate;
}

double amortizationTable::getStartingPrinciple(){
  return startingPrinciple;
}

double amortizationTable::getExtraPay(){
  return extraPay;
}

int setMonth(){
  int totalMonths;
  cout << "Enter the duration of the loan (months) \n";
  cin >> totalMonths;
  cout << "User entered: " << totalMonths << endl;
  return totalMonths;
}

double setPrinciple(){
  double startingPrinciple;
  cout << "Enter the dollar amount of the loan \n";
  cin >> startingPrinciple;
  cout << "User entered: " << startingPrinciple << endl;
  return startingPrinciple;
}

double setInterestRate(){
  double interestRate;
  cout << "Enter the interest rate of the loan \n" << "Form (0.XX)\n";
  cin >> interestRate;
  cout << "User entered: " << interestRate << endl;
  return interestRate;
}

double setExtraPay(){
  double extraPay;
  cout << "Enter the extra pay \n";
  cin >> extraPay;
  cout << "User entered: " << extraPay << endl << endl;
  return extraPay;
}
/***************************************************************/

// This constructor is used for the first month
// on each recursive month, a different constructor is used
currentMonthData::currentMonthData(double inputMonthlyPayment, double inputTotalPrinciple, double inputInterestRate, double inputExtraPay){
  monthlyPayment = inputMonthlyPayment;
  totalPrinciple = inputTotalPrinciple;
  interestRate = inputInterestRate;
  extraPay = inputExtraPay;

  // Constructor only used for 1st month; currnet month = 0
  currentMonth = 0;
  // Starting principle for this month is the total principle
  startingPrinciple = totalPrinciple;
  // The total paid will be the amount of months times how much is paid monthly
  totalPaid = (currentMonth+1)*(monthlyPayment+extraPay);
  // Interest paid in current montly is princple*monthlyIR
  interestPaid = startingPrinciple*interestRate;
  // Principle paid is the montly pay minus interest payment
  principlePaid = (monthlyPayment+extraPay) - interestPaid;
}

// This constructor is called within the function calculateMonth
// for each new data point
currentMonthData::currentMonthData(int inputCurrentMonth, double inputMonthlyPayment, double inputTotalPrinciple, double inputStartingPrinciple, double inputInterestRate, double inputTotalPrinciplePaid, double inputTotalInterestPaid, double inputExtraPay){
  currentMonth = inputCurrentMonth;
  monthlyPayment = inputMonthlyPayment;
  startingPrinciple = inputStartingPrinciple;
  interestRate = inputInterestRate;
  totalInterestPaid = inputTotalInterestPaid;
  totalPrinciplePaid = inputTotalPrinciplePaid;
  extraPay = inputExtraPay;
  totalPrinciple = inputTotalPrinciple;

  // The total paid will be the amount of months times how much is paid monthly
  totalPaid = (currentMonth+1)*(monthlyPayment+extraPay);
  // Interest paid in current montly is princple*monthlyIR
  interestPaid = (startingPrinciple)*interestRate;
  // Principle paid is the montly pay minus interest payment
  principlePaid = (monthlyPayment+extraPay) - interestPaid;
}

  // Recursively creates data points for each month
void currentMonthData::calculateMonth(){
  totalPrinciplePaid += principlePaid;
  principleRemaining  = totalPrinciple - totalPrinciplePaid;
  totalInterestPaid += interestPaid;
  // subtracting principle paid from previous months
  // startingPrinciple makes current months starting principle
  startingPrinciple -= principlePaid;

  // Runs on the last line to reimburse user if their payment is
  // higher than the remaining balance
  if(principleRemaining<0){
    reimburseRemainder();
  }

  // Month data is printed after possible reimbursment and before a
  // month is calculated
  printCurrentMonth();

  // if the principle remaining is more than zero, another month has to be calculated
  if(principleRemaining > 0){
    currentMonth++;
    // create a new month data point
    currentMonthData recursedMonth(currentMonth, monthlyPayment,totalPrinciple, startingPrinciple, interestRate, totalPrinciplePaid, totalInterestPaid, extraPay);
    recursedMonth.calculateMonth();
  }
}

void currentMonthData::printCurrentMonth(){
  cout << setw(10) << currentMonth << setw(15) << monthlyPayment << setw(15) << principleRemaining;
  cout << setw(15) << principlePaid << setw(15) << interestPaid << setw(15) << totalPaid;
  cout << setw(15) << totalPrinciplePaid << setw(15) << totalInterestPaid << endl;

}

  // Called when total owed is below zero
  // reimburses user from amount paid that months
void currentMonthData::reimburseRemainder(){
  // since principleRemaining is negative, its added to each total
  principlePaid += principleRemaining;
  totalPaid += principleRemaining;
  totalPrinciplePaid += principleRemaining;

  // principle remaining is now zero
  principleRemaining = 0;
}

void printAxis(){
  cout << setw(10) << left << "Month" << setw(15) << left << "Monthly" << setw(15) << left << "Principle";
  cout << setw(15) << left << "Principle" << setw(15) << left << "Interest"<< setw(15) << left << "Total";
  cout << setw(15) << left << "Total" << setw(15) << left << "Total"<< endl;

  cout << setw(10) << left << " " << setw(15) << left << "Pay" << setw(15) << left << "Remaining";
  cout << setw(15) << left << "Paid" << setw(15) << left << "Paid"<< setw(15) << left << "Paid";
  cout << setw(15) << left << "Principle" << setw(15) << left << "Interest"<< endl;
}


/**************************************************************/

int main(){
  int months;
  double principle, interestRate, extraPay;
  cout<<fixed<<setprecision(2);

  // Get necessary parameters
  months = setMonth();
  principle = setPrinciple();
  interestRate = setInterestRate();
  extraPay = setExtraPay();

  amortizationTable table(months, principle, interestRate, extraPay);
  printAxis();
  currentMonthData data(table.getMonthlyPayment(), table.getStartingPrinciple(), table.getInterestRate(), table.getExtraPay());
  data.calculateMonth();
}
